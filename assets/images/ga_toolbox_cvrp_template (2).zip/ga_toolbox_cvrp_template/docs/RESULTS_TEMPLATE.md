# Experimental results

## Instance
- Source filename:
- Number of customers:
- Vehicle capacity:
- Distance definition:
- Preprocessing:

## GA configuration
- Population size:
- Generations:
- Crossover rate:
- Mutation rate and interpretation:
- Selection:
- Crossover:
- Mutation:
- Replacement:
- Infeasibility policy:
- Seeds:

## Results
| Run / seed | Best total distance | Feasible? | Runtime | Notes |
|---|---:|---|---:|---|
| | | | | |

## Summary
- Best observed cost:
- Mean best cost:
- Standard deviation:
- Feasibility rate:
- Limitations:
- Reference comparison, if available:
