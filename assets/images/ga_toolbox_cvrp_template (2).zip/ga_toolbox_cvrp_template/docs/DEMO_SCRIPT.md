# TA demonstration script

Keep the normal run centered on `main.py`; open internal files only when asked.
1. Explain reusable GA core + operators + CVRP adapter.
2. Show configurable defaults in `GAConfig`.
3. Explain chromosome representations and why CVRP uses integer permutations.
4. Demonstrate Selection, Crossover, Mutation and Replacement.
5. Run on the instructor's actual instance.
6. Show vehicle routes, loads/capacities, and total distance.
7. Validate each customer exactly once and every route within capacity.
8. Show actual repeated-run results and stochastic variation.
9. Explain limitations honestly; GA does not guarantee a global optimum.
