# Prompt for each team member using AI

Attach the assignment, relevant lectures/labs, `CONTRACT.md`, and `TEAM_OWNERSHIP.md`. Fill in the assigned files.

---
You are helping implement one module in a five-person Python project: a reusable Genetic Algorithm Toolbox and a CVRP example.

My assigned files:
- [LIST ONLY MY OWNED FILES]

Rules:
1. Read the assignment, lecture/lab material, CONTRACT.md and TEAM_OWNERSHIP.md first.
2. Implement only my assigned files unless I ask for a coordinated contract change.
3. Do not rename public functions or change argument order, return conventions, chromosome format, or cost direction.
4. Do not use a GA/optimization library or Google OR-Tools.
5. Use Python 3.10+, type hints, readable docstrings, and the passed random.Random instance.
6. Lower cost is better.
7. Do not mutate parents or input populations when the contract says to return copies.
8. Add tests for normal cases and edge cases.
9. If lecture material conflicts with the contract, explain the conflict and propose the smallest change before coding; do not guess.
10. Do not invent test results. Give exact commands to run.
11. Before finalizing, list implemented public functions, contract compliance, tests, and any unresolved integration questions.
12. Check compatibility with the other modules' documented interfaces.

Return implementation for my assigned files, tests, contract concerns, test commands, and a short TA-ready explanation.
---
