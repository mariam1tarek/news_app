# Team ownership

This is a proposed split; review workload weekly and rebalance if one task proves significantly harder.

## Person 1 — Engine and configuration
Owns: `ga_toolbox/config.py`, `ga_toolbox/engine.py`, `ga_toolbox/interfaces.py` (shared; changes require agreement).
Implement config validation, generic generation loop, callback integration, best-so-far history and stop condition. Do not put CVRP logic in the engine.

## Person 2 — Representations and crossover
Owns: `ga_toolbox/representations.py`, `ga_toolbox/operators/crossover.py`, `tests/test_crossover.py`.
Implement binary/integer/float validators, multi-point crossover, OX, and permutation-preservation tests.

## Person 3 — Selection, mutation and replacement
Owns: `ga_toolbox/operators/selection.py`, `mutation.py`, `replacement.py`, `tests/test_operators.py`.
Implement two selection, three mutation, two replacement methods. Lower cost is better.

## Person 4 — CVRP model and data
Owns: `ga_toolbox/problems/cvrp.py`, `data_loader.py`, `tests/test_cvrp.py`.
Implement data validation, decoder, cost, feasibility and parser for the actual course instance.

## Person 5 — Integration, tests and experiments
Owns: `main.py`, `experiments.py`, `tests/test_engine.py`, `docs/RESULTS_TEMPLATE.md`, `docs/DEMO_SCRIPT.md`.
Wire the completed modules, run end-to-end tests, check every customer/capacity, record real experiments, and prepare the demo.

## Fairness rules
Every member tests their own code, reviews at least one teammate's PR, and helps resolve integration bugs in their own module. Person 5 must do real integration tests and experiments, not only presentation. Person 1 must not be the sole person responsible for all integration.
