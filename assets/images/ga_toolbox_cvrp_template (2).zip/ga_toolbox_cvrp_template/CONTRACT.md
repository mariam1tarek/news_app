# Interface Contract — read before coding

If code and this document disagree, stop and agree on one change before continuing.

## Shared conventions
- Python 3.10+; package name `ga_toolbox`.
- Chromosomes are Python lists. CVRP chromosomes are permutations of customer IDs `1..n`; depot ID `0` is excluded.
- **Cost minimization:** every `fitness_function(chromosome)` returns a numeric cost where lower is better. All Selection and Replacement methods must treat lower cost as better.
- Operators return new lists and do not mutate parents or input populations.
- Use the supplied `random.Random` object for randomness; do not use module-global random calls.
- Do not add GA/optimization libraries or Google OR-Tools.
- The final CVRP input parser must follow the instructor's actual sample format; do not invent its format.

## Config
`GAConfig` fields: `population_size`, `generations`, `crossover_rate`, `mutation_rate`, `elitism_count`, `tournament_size`, `seed`.
Validate sizes, rates in `[0,1]`, and elitism range.

## Callbacks
- `fitness_function(chromosome) -> float`: cost to minimize.
- `feasibility_function(chromosome) -> bool`.
- Optional `repair_function(chromosome) -> chromosome`.
- `initializer(count, rng) -> population`.

The engine is problem-agnostic. No CVRP rules inside `engine.py`.

## Operators
- Selection: `select(population, costs, count, rng) -> population`. May select the same candidate more than once. `len(costs) == len(population)`.
- Crossover: `cross(parent1, parent2, rng) -> (child1, child2)`. Parents remain unchanged.
- Multi-point crossover requires equal-length parents but does not preserve permutations; do not use it for CVRP unless repaired.
- Order crossover (OX) requires both parents to contain the same unique items. Children preserve that exact set with no duplicates.
- Mutation: `mutate(chromosome, rng) -> chromosome`.
- Proposed mutations: binary bit-flip, permutation swap, floating-point Gaussian. Confirm lecture expectations.
- Replacement: `replace(old_population, offspring, old_costs, offspring_costs, config) -> population`. Return exactly `config.population_size` individuals; lower cost is better.

## CVRP
- Node `0` is depot; customers are `1..n`.
- `distance_matrix[i][j]` is distance from node i to j.
- `demands[i]` is demand; `demands[0] == 0`; all demands and distances are non-negative; capacity is positive.
- Routes are lists of customer IDs **without** depot markers. Display adds depot at beginning/end.
- `decode_routes(chromosome) -> list[list[int]]`.
- Cost sums depot-to-first, between-customer, and last-to-depot distances for each route.
- Feasibility checks the permutation and each route's load against capacity.
- Proposed baseline decoder: scan permutation in order; start a new route when the next customer would exceed capacity. This is feasible when every individual demand <= capacity, but restricts reachable route partitions. Document this limitation.
- Fail early if any individual demand exceeds capacity.

## Engine flow
1. Create initial population via initializer callback.
2. Evaluate costs and feasibility.
3. Apply explicit infeasibility policy (repair, reject/regenerate, or penalty); never imply repair happens if it does not.
4. Select parents, crossover probabilistically, mutate according to documented rate interpretation.
5. Evaluate offspring and replace population.
6. Track best-so-far and history; stop after configured generations.

## Edge cases
- No empty populations.
- Validate permutations, dimensions, rates, finite costs and distances.
- Every customer served exactly once; every route respects capacity.
- Same seed + same inputs + same code should be reproducible.
- Mutation-rate interpretation (per chromosome vs per gene) must be documented.
- If changing this contract, update this file and tests in the same PR and notify affected owners.
