# GA Toolbox + CVRP — Project Template

This is a contract-first scaffold, not a completed assignment. It gives five members agreed interfaces and file ownership.

- Python 3.10+, standard library for runtime.
- Do not use a GA library or Google OR-Tools.
- Confirm the selected operators match your lectures/labs.
- `NotImplementedError` marks unfinished implementation tasks.

Start by reading `CONTRACT.md` and `TEAM_OWNERSHIP.md`.

Run from the repository root:
```bash
python main.py --help
python -m pytest
```

The scaffold is expected to have failing tests / unfinished paths until implementation is complete.
