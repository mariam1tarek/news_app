"""Selection operators. Lower cost is always better. Person 3 owns this file."""

from random import Random
from ..interfaces import CostList, Population


def tournament_selection(population: Population, costs: CostList, count: int,
                         rng: Random, tournament_size: int = 3) -> Population:
    """Return `count` copied parents. Repeated selections are allowed; inputs stay unchanged."""
    raise NotImplementedError("Person 3: implement tournament selection")


def roulette_wheel_selection(population: Population, costs: CostList, count: int,
                             rng: Random) -> Population:
    """Return `count` copied parents; convert minimized costs into safe selection weights."""
    raise NotImplementedError("Person 3: implement roulette-wheel selection")
