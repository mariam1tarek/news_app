"""Mutation operators. Each returns a new chromosome. Person 3 owns this file."""

from random import Random
from ..interfaces import Chromosome


def bit_flip_mutation(chromosome: Chromosome, rng: Random,
                      gene_rate: float = 0.05) -> Chromosome:
    """Flip binary genes with the per-gene probability."""
    raise NotImplementedError("Person 3: implement bit-flip mutation")


def swap_mutation(chromosome: Chromosome, rng: Random) -> Chromosome:
    """Swap two positions; preserves a permutation's item set."""
    raise NotImplementedError("Person 3: implement swap mutation")


def gaussian_mutation(chromosome: Chromosome, rng: Random, gene_rate: float = 0.05,
                       sigma: float = 0.1,
                       bounds: tuple[float, float] | None = None) -> Chromosome:
    """Add Gaussian noise to selected numeric genes; clamp to bounds if provided."""
    raise NotImplementedError("Person 3: implement Gaussian mutation")
