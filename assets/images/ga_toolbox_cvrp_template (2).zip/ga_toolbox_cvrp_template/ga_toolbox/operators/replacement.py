"""Replacement strategies. Lower cost is better. Person 3 owns this file."""

from ..config import GAConfig
from ..interfaces import CostList, Population


def generational_replacement(old_population: Population, offspring: Population,
                             old_costs: CostList, offspring_costs: CostList,
                             config: GAConfig) -> Population:
    """Return exactly N candidates; new generation plus configured best old elites."""
    raise NotImplementedError("Person 3: implement generational replacement")


def steady_state_replacement(old_population: Population, offspring: Population,
                             old_costs: CostList, offspring_costs: CostList,
                             config: GAConfig) -> Population:
    """Return exactly N candidates; proposed policy is best N from old + offspring."""
    raise NotImplementedError("Person 3: implement steady-state replacement")
