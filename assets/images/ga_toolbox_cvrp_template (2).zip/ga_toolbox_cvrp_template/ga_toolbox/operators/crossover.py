"""Crossover operators. Parents must not be mutated. Person 2 owns this file."""

from random import Random
from ..interfaces import Chromosome


def multi_point_crossover(parent1: Chromosome, parent2: Chromosome, rng: Random,
                          points: int = 2) -> tuple[Chromosome, Chromosome]:
    """Equal-length parents; generic operator does not preserve permutations."""
    raise NotImplementedError("Person 2: implement multi-point crossover")


def order_crossover(parent1: Chromosome, parent2: Chromosome,
                    rng: Random) -> tuple[Chromosome, Chromosome]:
    """OX for permutations: children contain exactly the same unique items as their parents."""
    raise NotImplementedError("Person 2: implement order crossover")
