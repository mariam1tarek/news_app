"""Representation validation helpers. Person 2 owns this file."""

from __future__ import annotations
from .interfaces import Chromosome


def validate_binary(chromosome: Chromosome) -> None:
    """Accept only bool or integer 0/1 genes."""
    raise NotImplementedError("Person 2: implement binary validation")


def validate_integer(chromosome: Chromosome) -> None:
    """Accept integer genes; reject bool, because bool subclasses int in Python."""
    raise NotImplementedError("Person 2: implement integer validation")


def validate_float(chromosome: Chromosome) -> None:
    """Accept finite numeric genes according to the team's agreed policy."""
    raise NotImplementedError("Person 2: implement float validation")


def validate_permutation(chromosome: Chromosome, expected_items: set[int] | None = None) -> None:
    """Require unique integer genes; if expected_items is given, require exact set equality."""
    raise NotImplementedError("Person 2: implement permutation validation")
