"""GA hyperparameters and validation."""

from dataclasses import dataclass


@dataclass(slots=True)
class GAConfig:
    population_size: int = 100
    generations: int = 200
    crossover_rate: float = 0.8
    mutation_rate: float = 0.05
    elitism_count: int = 2
    tournament_size: int = 3
    seed: int | None = 42

    def __post_init__(self) -> None:
        if self.population_size < 2:
            raise ValueError("population_size must be >= 2")
        if self.generations < 1:
            raise ValueError("generations must be >= 1")
        if not 0.0 <= self.crossover_rate <= 1.0:
            raise ValueError("crossover_rate must be in [0, 1]")
        if not 0.0 <= self.mutation_rate <= 1.0:
            raise ValueError("mutation_rate must be in [0, 1]")
        if not 0 <= self.elitism_count < self.population_size:
            raise ValueError("elitism_count must be >= 0 and < population_size")
        if self.tournament_size < 1:
            raise ValueError("tournament_size must be >= 1")
