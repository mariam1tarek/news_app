"""Problem-agnostic GA engine. Person 1 owns this file; no CVRP-specific rules."""

from dataclasses import dataclass, field
from .config import GAConfig
from .interfaces import (FitnessFunction, FeasibilityFunction, InitializerFunction,
                         RepairFunction)


@dataclass(slots=True)
class GAResult:
    best_chromosome: list[bool | int | float]
    best_cost: float
    best_cost_history: list[float] = field(default_factory=list)
    generations_completed: int = 0


class GeneticAlgorithm:
    """Inject initializer, callbacks, and operators; minimize the returned cost."""

    def __init__(self, config: GAConfig, initializer: InitializerFunction,
                 fitness_function: FitnessFunction,
                 feasibility_function: FeasibilityFunction,
                 selection_operator, crossover_operator, mutation_operator,
                 replacement_operator, repair_function: RepairFunction | None = None):
        self.config = config
        self.initializer = initializer
        self.fitness_function = fitness_function
        self.feasibility_function = feasibility_function
        self.selection_operator = selection_operator
        self.crossover_operator = crossover_operator
        self.mutation_operator = mutation_operator
        self.replacement_operator = replacement_operator
        self.repair_function = repair_function

    def run(self) -> GAResult:
        """Implement generation loop, explicit infeasibility policy, history and best-so-far."""
        raise NotImplementedError("Person 1: implement GA engine")
