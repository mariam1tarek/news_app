"""Synthetic development instance only; replace with the course's actual example."""

from .cvrp import CVRPInstance, euclidean_distance_matrix


def make_demo_instance() -> CVRPInstance:
    coordinates = [(0, 0), (2, 1), (4, 1), (1, 4), (5, 4), (3, 5)]
    demands = [0, 4, 6, 3, 5, 2]
    return CVRPInstance(
        distance_matrix=euclidean_distance_matrix(coordinates),
        demands=demands,
        vehicle_capacity=10,
    )
