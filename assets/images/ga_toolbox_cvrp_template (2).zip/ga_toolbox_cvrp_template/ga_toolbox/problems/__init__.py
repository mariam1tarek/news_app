"""Problem-specific adapters."""
