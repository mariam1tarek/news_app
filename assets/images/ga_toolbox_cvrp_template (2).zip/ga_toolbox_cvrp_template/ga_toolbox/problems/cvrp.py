"""CVRP data model, decoder, objective and feasibility. Person 4 owns this file."""

from dataclasses import dataclass
from typing import Sequence
from ..interfaces import Chromosome


@dataclass(slots=True)
class CVRPInstance:
    # Matrix node 0 is depot; customers are 1..n. demands[0] should be 0.
    distance_matrix: list[list[float]]
    demands: list[float]
    vehicle_capacity: float

    def __post_init__(self) -> None:
        """Validate dimensions, finite/non-negative values, capacity, and impossible demands."""
        raise NotImplementedError("Person 4: implement instance validation")

    @property
    def customer_ids(self) -> list[int]:
        return list(range(1, len(self.demands)))

    def decode_routes(self, chromosome: Chromosome) -> list[list[int]]:
        """Sequential capacity decoder; route lists exclude depot markers."""
        raise NotImplementedError("Person 4: implement decoder")

    def route_load(self, route: Sequence[int]) -> float:
        """Sum demand for customers in a route."""
        raise NotImplementedError("Person 4: implement route load")

    def total_distance(self, routes: Sequence[Sequence[int]]) -> float:
        """Sum depot departure, inter-customer distances, and depot return for each route."""
        raise NotImplementedError("Person 4: implement total distance")

    def is_feasible_chromosome(self, chromosome: Chromosome) -> bool:
        """Check exact customer permutation and all route capacity constraints."""
        raise NotImplementedError("Person 4: implement feasibility check")

    def fitness(self, chromosome: Chromosome) -> float:
        """Return total distance as a minimization cost."""
        raise NotImplementedError("Person 4: implement fitness")


def euclidean_distance_matrix(coordinates: Sequence[tuple[float, float]]) -> list[list[float]]:
    """Optional helper for coordinates including depot at index 0."""
    raise NotImplementedError("Person 4: implement Euclidean distance helper")
