"""Load the instructor-provided CVRP format. Person 4 owns this file."""

from pathlib import Path
from .cvrp import CVRPInstance


def load_cvrp_instance(path: str | Path) -> CVRPInstance:
    """Inspect the actual course example before choosing a parser format."""
    raise NotImplementedError("Person 4: implement course-format parser")
