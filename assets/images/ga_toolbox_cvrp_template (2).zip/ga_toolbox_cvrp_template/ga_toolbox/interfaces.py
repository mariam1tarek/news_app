"""Shared types and callback contracts. Coordinate changes with the whole team."""

from __future__ import annotations
from collections.abc import Callable, Sequence
from random import Random
from typing import TypeAlias

Gene: TypeAlias = bool | int | float
Chromosome: TypeAlias = list[Gene]
Population: TypeAlias = list[Chromosome]
FitnessFunction: TypeAlias = Callable[[Chromosome], float]  # cost to minimize
FeasibilityFunction: TypeAlias = Callable[[Chromosome], bool]
RepairFunction: TypeAlias = Callable[[Chromosome], Chromosome]
InitializerFunction: TypeAlias = Callable[[int, Random], Population]
CostList: TypeAlias = Sequence[float]
