"""Single entry point. Person 5 owns integration; coordinate with Person 1 and 4."""

import argparse
from ga_toolbox import GAConfig, GeneticAlgorithm
from ga_toolbox.problems.demo_instance import make_demo_instance


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the GA Toolbox on CVRP.")
    parser.add_argument("--population-size", type=int, default=100)
    parser.add_argument("--generations", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    instance = make_demo_instance()
    config = GAConfig(population_size=args.population_size,
                      generations=args.generations, seed=args.seed)

    # TODO: wire the agreed operators, permutation initializer, and CVRP callbacks.
    # The final version must use the instructor's instance and match required output format.
    raise NotImplementedError("Person 5: complete end-to-end wiring")


if __name__ == "__main__":
    main()
