# GitHub collaboration rules

- Use feature branches, not direct pushes to `main`.
- Suggested branches: `feat/ga-engine`, `feat/crossover`, `feat/operators`, `feat/cvrp`, `feat/integration`.
- Keep PRs small and focused; include tests and a short explanation.
- Primary ownership is in `TEAM_OWNERSHIP.md`.
- `CONTRACT.md`, `interfaces.py`, `__init__.py` are shared files; coordinate changes.
- Do not independently rename methods or change argument / return conventions.
- Pull latest `main` before starting and before opening a PR.
- Resolve conflicts with the affected file owner; do not blindly accept "ours" or "theirs".
- Definition of done: implementation, type hints/docstrings, tests for normal and edge cases, imports work from repo root, no unfinished placeholder in the production path.
