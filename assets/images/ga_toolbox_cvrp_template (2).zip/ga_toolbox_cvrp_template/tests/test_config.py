import pytest
from ga_toolbox.config import GAConfig


def test_default_config_is_valid():
    config = GAConfig()
    assert config.population_size >= 2
    assert config.generations >= 1


def test_invalid_crossover_rate_is_rejected():
    with pytest.raises(ValueError):
        GAConfig(crossover_rate=1.5)
