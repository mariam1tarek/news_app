"""Person 2: add tests for crossover."""

# Required: parents unchanged; child lengths; OX exact item set and no duplicates;
# invalid inputs rejected; seeded RNG is reproducible.
