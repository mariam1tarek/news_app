"""Person 1 + Person 5: engine and integration tests."""

# Required: toy non-CVRP minimization problem; population size preserved;
# best-so-far history non-increasing; explicit infeasibility policy; reproducible seed.
