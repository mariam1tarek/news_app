"""Person 4: add CVRP tests."""

# Required: data validation; every customer decoded once; capacity respected;
# distance includes depot departure/return; invalid permutation infeasible;
# demand > capacity fails early.
