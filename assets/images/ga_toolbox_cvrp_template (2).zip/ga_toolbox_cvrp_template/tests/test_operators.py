"""Person 3: add tests for Selection, Mutation and Replacement."""

# Required: correct selection count; lower cost favored; mutation constraints;
# replacement returns N; elitism keeps best old candidate; invalid inputs rejected.
